source("R/staffing_functions.R")
library(tidyr)
set.seed(3)

obj <- readRDS("data/clean/calls_clean.rds"); fr <- readRDS("data/clean/forecast_results.rds")
fc <- fr$fc; sigma <- fr$sigma_day; aht <- obj$aht_value
size_nb <- 1 / sigma^2                      # negative binomial with extra-Poisson variance (sigma * mean)^2

# ---- Staffing policies: agents for each interval, then service level under the ACTUAL arrivals -------------------------
agents_for <- function(forecast, mode = "mean", q = 0.5) {
  demand <- switch(mode, mean = forecast, poisson = qpois(q, forecast), nb = qnbinom(q, size = size_nb, mu = forecast))
  sapply(demand, function(v) min_agents(max(v, 0.01), aht))
}
evaluate <- function(label, forecast_col, mode = "mean", q = 0.5) {
  fc |> mutate(forecast = .data[[forecast_col]]) |> group_by(day) |>
    mutate(agents = agents_for(forecast, mode, q)) |> ungroup() |>
    mutate(sl = mapply(service_level, agents, actual, MoreArgs = list(aht = aht)), policy = label)
}
summarise_policy <- function(d) d |> group_by(policy) |> summarise(
  agent_hours = sum(agents) * 0.5, call_weighted_sl = sum(sl * actual) / sum(actual),
  intervals_meeting_target = mean(sl >= TARGET_SL), intervals_below_70 = mean(sl < 0.70),
  missed_calls = sum((1 - sl) * actual), .groups = "drop") |>
  mutate(total_cost = agent_hours * AGENT_COST_PER_HOUR + missed_calls * MISSED_CALL_COST)

# oracle: staff for the TRUE mean arrival rate (still faces Poisson randomness)
fc$oracle <- fc$true_mean
runs <- bind_rows(
  evaluate("Naive (same slot last week), mean", "naive"),
  evaluate("Average of last 4 weeks, mean", "avg4"),
  evaluate("Profile forecast, mean", "profile"),
  evaluate("Oracle (true mean rate), mean", "oracle"),
  evaluate("Profile + Poisson 80th percentile", "profile", "poisson", 0.8),
  evaluate("Profile + NB 80th percentile", "profile", "nb", 0.8))
policy_tbl <- summarise_policy(runs) |> arrange(total_cost)
print(policy_tbl)

# ---- The cost / service frontier: sweep the demand quantile --------------------------------------------------------------
grid <- expand.grid(q = c(0.5, 0.6, 0.7, 0.8, 0.9, 0.95), mode = c("poisson", "nb"), stringsAsFactors = FALSE)
frontier <- bind_rows(lapply(seq_len(nrow(grid)), function(i) {
  r <- evaluate(paste(grid$mode[i], grid$q[i]), "profile", grid$mode[i], grid$q[i])
  summarise_policy(r) |> mutate(mode = grid$mode[i], q = grid$q[i])
}))
print(frontier)
best <- frontier |> group_by(mode) |> slice_min(total_cost, n = 1, with_ties = FALSE) |> ungroup()
print(best)

# ---- Where do the misses happen? By time of day and day of week -----------------------------------------------------------------
miss_where <- runs |> filter(policy == "Profile forecast, mean") |> group_by(interval) |>
  summarise(share_below_target = mean(sl < TARGET_SL), mean_sl = mean(sl), .groups = "drop")

# ---- Bootstrap over test days: is the quantile policy reliably better? ----------------------------------------------------------
B <- 500; day_ids <- unique(fc$day)
a <- runs |> filter(policy == "Profile forecast, mean"); b <- runs |> filter(policy == "Profile + NB 80th percentile")
per_day <- function(r) r |> group_by(day) |> summarise(met = mean(sl >= TARGET_SL), cost = sum(agents) * 0.5 * AGENT_COST_PER_HOUR + sum((1 - sl) * actual) * MISSED_CALL_COST, .groups = "drop")
pa <- per_day(a); pb <- per_day(b)
boot <- bind_rows(lapply(seq_len(B), function(i) { s <- sample(seq_along(day_ids), replace = TRUE)
  tibble(rep = i, met_gain = mean(pb$met[s]) - mean(pa$met[s]), cost_saving = sum(pa$cost[s]) - sum(pb$cost[s])) }))
boot_summary <- boot |> pivot_longer(-rep, names_to = "quantity", values_to = "value") |> group_by(quantity) |>
  summarise(mean = mean(value), lower = quantile(value, 0.025), upper = quantile(value, 0.975), .groups = "drop")
print(boot_summary)

saveRDS(list(policy_tbl = policy_tbl, frontier = frontier, best = best, miss_where = miss_where, boot_summary = boot_summary,
             sigma = sigma, aht = aht, B = B), "data/clean/staffing_results.rds")
