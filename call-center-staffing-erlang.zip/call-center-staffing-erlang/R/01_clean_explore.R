source("R/staffing_functions.R")
library(tidyr)
set.seed(1)

calls <- read.csv("data/raw/call_log.csv", stringsAsFactors = FALSE)
cleaned <- clean_calls(calls); x <- cleaned$calls; N <- cleaned$N; dow <- cleaned$dow
print(cleaned$log)
stopifnot(nrow(N) == 112, ncol(N) == N_INTERVALS, all(N >= 0))

# ---- Volume by weekday and time of day ------------------------------------------------------------------------------
by_dow <- tibble(dow = factor(c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"), levels = c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")),
                 mean_calls = sapply(1:7, function(k) mean(rowSums(N[dow == k, , drop = FALSE]))))
print(by_dow)
profile <- tibble(interval = seq_len(N_INTERVALS), clock = sprintf("%02d:%02d", 8 + (interval - 1) %/% 2, ((interval - 1) %% 2) * 30),
                  mean_calls = colMeans(N[dow <= 5, ]))
print(profile)

# ---- Handling time and abandonment ---------------------------------------------------------------------------------------
answered <- x[x$abandoned == 0 & !is.na(x$handle_secs), ]
aht <- tibble(aht_mean = mean(answered$handle_secs), aht_median = median(answered$handle_secs), aht_p90 = quantile(answered$handle_secs, 0.9),
              abandonment_rate = mean(x$abandoned))
print(aht)

# ---- Is demand Poisson? Index of dispersion for the same weekday and interval across weeks ------------------------------
# For a Poisson process the variance equals the mean. After removing the weekday pattern, extra variance
# means a shared daily factor that no forecast can see.
weekday_ids <- which(dow == 3)                           # Wednesdays
M <- N[weekday_ids, ]
disp <- tibble(interval = seq_len(N_INTERVALS), mean = colMeans(M), variance = apply(M, 2, var), index = variance / mean)
cat("Median index of dispersion across intervals (Wednesdays):", round(median(disp$index), 2), "(1 = Poisson)\n")
day_tot <- rowSums(N); trend_fit <- lm(log(day_tot) ~ seq_along(day_tot) + factor(dow))
cat("Estimated daily growth rate:", round(coef(trend_fit)[2], 4), "\n")
cat("Residual sd of log daily volume:", round(sd(resid(trend_fit)), 3), "\n")

saveRDS(list(N = N, dow = dow, log = cleaned$log, by_dow = by_dow, profile = profile, aht = aht, disp = disp,
             aht_value = mean(answered$handle_secs)), "data/clean/calls_clean.rds")
