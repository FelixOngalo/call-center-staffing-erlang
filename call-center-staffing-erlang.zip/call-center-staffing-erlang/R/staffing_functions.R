# Functions for the call-centre staffing project: a call simulator with KNOWN arrival rates, cleaning,
# arrival forecasts, the Erlang C queueing model and staffing policies.

library(dplyr)
library(tibble)

N_INTERVALS <- 24          # half-hours from 08:00 to 20:00
INTERVAL_SECS <- 1800
TRUE_AHT <- 360            # average handling time in seconds
TARGET_SL <- 0.80          # 80% of calls answered ...
TARGET_SECS <- 20          # ... within 20 seconds (the classic "80/20")
AGENT_COST_PER_HOUR <- 28
MISSED_CALL_COST <- 10     # cost of a call that waits longer than the target (lost goodwill, abandonment)

#' Simulate a call centre: calls arrive as a Poisson process whose rate depends on weekday, time of day and a
#' slow trend, and on a random multiplier for each day (marketing, weather, outages) that no forecast can see.
#' Returns call-level records plus the true mean arrivals per interval.
simulate_calls <- function(weeks = 16, seed = 1, messy = TRUE) {
  set.seed(seed)
  days <- weeks * 7; I <- N_INTERVALS
  dow_f <- c(1.15, 1.05, 1.0, 1.0, 1.1, 0.55, 0.40)                       # Monday to Sunday
  prof <- exp(-((seq_len(I) - 7) / 5)^2) + 0.8 * exp(-((seq_len(I) - 18) / 4)^2) + 0.25; prof <- prof / sum(prof)
  trend <- 1 + 0.004 * (seq_len(days) - 1)
  dayfx <- exp(rnorm(days, 0, 0.10))
  event <- rep(1, days); event[days - c(31, 30, 16)] <- 1.6                 # three demand spikes in the last 5 weeks
  dow <- ((seq_len(days) - 1) %% 7) + 1
  lam <- t(sapply(seq_len(days), function(d) 520 * dow_f[dow[d]] * trend[d] * dayfx[d] * event[d] * prof))
  N <- matrix(rpois(days * I, lam), days, I)

  d_idx <- rep(rep(seq_len(days), I), times = as.vector(N)); i_idx <- rep(rep(seq_len(I), each = days), times = as.vector(N))
  m <- length(d_idx)
  start <- as.POSIXct("2026-01-05 08:00:00", tz = "UTC")                      # a Monday
  ts <- start + (d_idx - 1) * 86400 + (i_idx - 1) * INTERVAL_SECS + runif(m, 0, INTERVAL_SECS)
  handle <- rlnorm(m, log(TRUE_AHT) - 0.5 * 0.6^2, 0.6)
  abandoned <- rbinom(m, 1, 0.08); handle[abandoned == 1] <- 0
  calls <- tibble(call_id = sprintf("K%07d", seq_len(m)), call_start = format(ts, "%Y-%m-%d %H:%M:%S"),
                  handle_secs = round(handle), abandoned = abandoned, queue = "support") |> arrange(call_start)
  truth <- list(lambda = lam, aht = TRUE_AHT, counts = N, dow = dow)

  if (messy) {
    k <- nrow(calls)
    i_t <- sample(k, round(0.03 * k)); calls$call_start[i_t] <- sub(" ", "T", calls$call_start[i_t])              # ISO "T" separator in some rows
    i_neg <- sample(k, 25); calls$handle_secs[i_neg] <- -1                          # negative handle times
    i_big <- sample(k, 25); calls$handle_secs[i_big] <- 36000                       # 10-hour handle times (never closed)
    test <- calls[sample(k, 300), ]; test$queue <- "test"; test$call_id <- paste0("T", test$call_id)
    calls <- bind_rows(calls, test, calls[sample(k, round(0.015 * k)), ]) |> arrange(call_start)      # test calls, duplicates
  }
  list(calls = calls, truth = truth)
}

#' Clean call records and build the day x interval matrix of arrivals (abandoned calls count as arrivals).
clean_calls <- function(calls) {
  n0 <- nrow(calls)
  x <- distinct(calls, call_id, .keep_all = TRUE); n_dup <- n0 - nrow(x)
  n_test <- sum(x$queue == "test"); x <- x[x$queue != "test", ]
  x$ts <- as.POSIXct(sub("T", " ", x$call_start), tz = "UTC")
  n_bad_handle <- sum(x$handle_secs < 0 | x$handle_secs > 7200); x$handle_secs[x$handle_secs < 0 | x$handle_secs > 7200] <- NA
  x$date <- as.Date(x$ts)
  x$day <- as.integer(x$date - min(x$date)) + 1
  secs <- as.numeric(format(x$ts, "%H")) * 3600 + as.numeric(format(x$ts, "%M")) * 60 + as.numeric(format(x$ts, "%S"))
  x$interval <- pmin(pmax(floor((secs - 8 * 3600) / INTERVAL_SECS) + 1, 1), N_INTERVALS)
  n_days <- max(x$day)
  N <- unclass(table(factor(x$day, seq_len(n_days)), factor(x$interval, seq_len(N_INTERVALS))))
  N <- matrix(as.numeric(N), n_days, N_INTERVALS)
  dow <- as.integer(format(min(x$date) + seq_len(n_days) - 1, "%u"))
  log <- tibble(step = c("Records received", "Duplicate call IDs removed", "Test-queue calls removed", "Impossible handle times set to missing", "Calls analysed", "Days"),
                value = c(n0, n_dup, n_test, n_bad_handle, nrow(x), n_days))
  list(calls = x, N = N, dow = dow, log = log)
}

# ---- Erlang C -----------------------------------------------------------------------------------------------
erlang_b <- function(c, a) { b <- 1; for (k in seq_len(c)) b <- a * b / (k + a * b); b }

#' Share of calls answered within `secs` seconds when `c` agents serve `n_calls` arrivals in a half hour.
#' Erlang C: offered load a = arrivals x handling time / interval length (in agent-equivalents); the probability that
#' a call has to wait is C = cB / (c - a(1 - B)), with B the Erlang B blocking probability.
service_level <- function(c, n_calls, aht, secs = TARGET_SECS) {
  if (n_calls <= 0) return(1)
  a <- n_calls * aht / INTERVAL_SECS
  if (c <= a) return(0)
  b <- erlang_b(c, a); pw <- c * b / (c - a * (1 - b))
  1 - pw * exp(-(c - a) * secs / aht)
}

#' The smallest number of agents that meets the target service level for `n_calls` arrivals.
min_agents <- function(n_calls, aht, target = TARGET_SL, secs = TARGET_SECS) {
  if (n_calls <= 0) return(1)
  c <- max(1, floor(n_calls * aht / INTERVAL_SECS) + 1)
  while (service_level(c, n_calls, aht, secs) < target) c <- c + 1
  c
}

# ---- Forecasts of arrivals per interval for day d, using only earlier days ----------------------------------------
f_naive <- function(N, d) N[d - 7, ]
f_avg4  <- function(N, d) colMeans(N[d - 7 * (1:4), , drop = FALSE])
f_profile <- function(N, d, slope) {
  idx <- d - 7 * (1:8)
  colMeans(N[idx, , drop = FALSE] * exp(slope * (d - idx)))       # same weekday, last 8 weeks, grown by the trend
}
