source("R/staffing_functions.R")
library(tidyr)
set.seed(2)

obj <- readRDS("data/clean/calls_clean.rds"); N <- obj$N; dow <- obj$dow
truth <- readRDS("data/clean/truth.rds")
days <- nrow(N); test_days <- (days - 27):days; train_end <- days - 28

# ---- Trend from the training period only -----------------------------------------------------------------------------
tr_days <- seq_len(train_end)
fit_trend <- lm(log(rowSums(N[tr_days, ])) ~ tr_days + factor(dow[tr_days]))
slope <- unname(coef(fit_trend)[2]); cat("Estimated daily trend:", round(slope, 4), "\n")

# ---- Day-level error of the profile forecast (the part Poisson noise cannot explain) --------------------------------
calib_days <- (train_end - 27):train_end
ratio <- sapply(calib_days, function(d) sum(N[d, ]) / sum(f_profile(N, d, slope)))
sigma_day <- sd(log(ratio))
cat("Day-level sd of log forecast error (from the last 28 training days):", round(sigma_day, 3), "\n")

# ---- Forecasts for each test day and accuracy ----------------------------------------------------------------------------
fc <- bind_rows(lapply(test_days, function(d) {
  tibble(day = d, interval = seq_len(N_INTERVALS), actual = N[d, ], true_mean = truth$lambda[d, ],
         naive = f_naive(N, d), avg4 = f_avg4(N, d), profile = f_profile(N, d, slope))
}))
wape <- function(f, a) sum(abs(f - a)) / sum(a)
accuracy <- tibble(method = c("naive", "avg4", "profile"),
  wape_vs_actual = sapply(c("naive", "avg4", "profile"), function(m) wape(fc[[m]], fc$actual)),
  wape_vs_true_mean = sapply(c("naive", "avg4", "profile"), function(m) wape(fc[[m]], fc$true_mean)),
  bias_pct = sapply(c("naive", "avg4", "profile"), function(m) 100 * (sum(fc[[m]]) / sum(fc$actual) - 1)),
  day_total_mape = sapply(c("naive", "avg4", "profile"), function(m) mean(abs(tapply(fc[[m]], fc$day, sum) / tapply(fc$actual, fc$day, sum) - 1))))
print(accuracy)
cat("WAPE of the TRUE mean against actual arrivals (the floor no forecast can beat):", round(wape(fc$true_mean, fc$actual), 3), "\n")

saveRDS(list(fc = fc, accuracy = accuracy, slope = slope, sigma_day = sigma_day, test_days = test_days,
             floor_wape = wape(fc$true_mean, fc$actual)), "data/clean/forecast_results.rds")
